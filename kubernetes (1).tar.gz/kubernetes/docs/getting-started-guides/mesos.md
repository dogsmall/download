This file has moved to: http://kubernetes.github.io/docs/getting-started-guides/mesos/


<!-- BEGIN MUNGE: GENERATED_ANALYTICS -->
[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/docs/getting-started-guides/mesos.md?pixel)]()
<!-- END MUNGE: GENERATED_ANALYTICS -->
