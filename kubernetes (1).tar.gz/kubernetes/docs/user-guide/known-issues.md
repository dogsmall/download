This file has moved to: https://github.com/kubernetes/kubernetes/blob/master/CHANGELOG.md

<!-- BEGIN MUNGE: GENERATED_ANALYTICS -->
[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/docs/user-guide/known-issues.md?pixel)]()
<!-- END MUNGE: GENERATED_ANALYTICS -->
