<!-- needed for gh-pages to render html files when imported -->
{% include <REPLACE-WITH-RELEASE-VERSION>/v1-definitions.html %}




<!-- BEGIN MUNGE: GENERATED_ANALYTICS -->
[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/docs/api-reference/v1/definitions.md?pixel)]()
<!-- END MUNGE: GENERATED_ANALYTICS -->
