This file has moved to [https://github.com/kubernetes/community/blob/master/contributors/devel/api_changes.md](https://github.com/kubernetes/community/blob/master/contributors/devel/api_changes.md)
